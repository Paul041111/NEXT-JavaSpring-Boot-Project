package com.mailflow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.mailflow.dto.LoginRequest;
import java.util.HashMap;
import java.util.Map;
import com.mailflow.model.User;
import com.mailflow.repository.UserRepository;

@RestController
public class AuthController {

  @Autowired
  private MongoTemplate mongoTemplate;

  @PostMapping("/register")
  public Map<String, String> register(
      @RequestBody Map<String, String> user) {

    mongoTemplate.save(user, "users");

    Map<String, String> response = new HashMap<>();
    response.put("message", "User registered successfully");

    return response;
  }

  @RequestMapping("/users")
  public class UserController {

    private UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {

      User user = userRepository.findByEmail(request.getEmail());

      if (user == null) {
        return ResponseEntity.badRequest().body("User not found");
      }

      // if (!user.getPassword().equals(request.getPassword())) {
      // return ResponseEntity.badRequest().body("Invalid password");
      // } ////user pwd compare db pwd

      return ResponseEntity.ok("Login successful");
    }
  }
}